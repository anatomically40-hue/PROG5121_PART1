/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.login;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Scanner;
import java.util.ArrayList;
/**
 *
 * @author Student
 */
public class Login {

    public static void main(String[] args) {
   Scanner scanner = new Scanner(system.in]);
   arraylist<login>users = new arraylist<>();//store a number of users

   system.out.println("\n wolcom to our app ! kindly select an option below:");0
    
   // main manu 
   system.out.println("\nmain manu:");
   system.println("1. REGISTERE");
   system.println("2. login);
  system.out.println("3. exit");
  system.out.println("choose an option:");
    // Check username
    public static boolean checkUserName(String username) {
        return username.contains("_") && username.length() <= 5;
    }

    // Check password
    public static boolean checkPasswordComplexity(String password) {

        boolean hasCapital = false;
        boolean hasNumber = false;
        boolean hasSpecial = false;

        if (password.length() >= 8) {
            for (int i = 0; i < password.length(); i++) {

                char ch = password.charAt(i);

                if (Character.isUpperCase(ch)) {
                    hasCapital = true;
                } else if (Character.isDigit(ch)) {
                    hasNumber = true;
                } else if (!Character.isLetterOrDigit(ch)) {
                    hasSpecial = true;
                }
            }
        }

        return hasCapital && hasNumber && hasSpecial;
    }

    // Check phone number
    public static boolean checkCellPhoneNumber(String phone) {
        return phone.startsWith("+27") && phone.length() <= 12;
    }

    // Register user
    public static String registerUser(String username, String password, String phone) {

        if (!checkUserName(username)) {
            return "Username is not correctly formatted";
        }

        if (!checkPasswordComplexity(password)) {
            return "Password is not correctly formatted";
        }

        if (!checkCellPhoneNumber(phone)) {
            return "Cell phone number incorrectly formatted";
        }

        storedUsername = username;
        storedPassword = password;
        storedPhone = phone;

        return "User registered successfully";
    }

    // Login user
    public static String loginUser(String username, String password) {

        if (username.equals(storedUsername) && password.equals(storedPassword)) {
            return "Welcome " + username;
        } else {
            return "Username or password incorrect";
        }
    }

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        // REGISTER
        System.out.println("=== REGISTER ===");

        System.out.print("Enter username: ");
        String username = input.nextLine();

        System.out.print("Enter password: ");
        String password = input.nextLine();

        System.out.print("Enter phone (+27...): ");
        String phone = input.nextLine();

        String result = registerUser(username, password, phone);
        System.out.println(result);

        // LOGIN
        System.out.println("\n=== LOGIN ===");

        System.out.print("Enter username: ");
        String loginUser = input.nextLine();

        System.out.print("Enter password: ");
        String loginPass = input.nextLine();

        String loginResult = loginUser(loginUser, loginPass);
        System.out.println(loginResult);

        input.close();
    }
}     
    }
}
